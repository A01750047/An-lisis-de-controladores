import matplotlib.pyplot as plt
import numpy as np

# Código elaborado para observar trayectorias y posteriormente ingresarlas al path generator

def oval_trajectory():
    cx = 5.5 - 3.0  # Desplazar a la izquierda para iniciar el óvalo en (5.5, 5.5)
    cy = 5.5
    a = 3.0
    b = 2.0
    points = 100
    x_vals, y_vals = [], []
    for i in range(points):
        t = 2 * np.pi * i / points
        x = cx + a * np.cos(t)
        y = cy + b * np.sin(t)
        x_vals.append(x)
        y_vals.append(y)
    return x_vals, y_vals

def figure_eight_trajectory():
    cx, cy = 5.5, 5.5
    a, b = 3.5, 2.0
    points = 200
    x_vals, y_vals = [], []
    for i in range(points):
        t = 2 * np.pi * i / points
        x = cx + a * np.sin(t)
        y = cy + b * np.sin(t) * np.cos(t)
        x_vals.append(x)
        y_vals.append(y)
    return x_vals, y_vals

def zigzag_trajectory():
    x_start, y_start = 5.5, 5.5
    width = 4.0
    height = 2.0
    segments = 4
    dx = width / segments
    x_vals, y_vals = [], []

    for i in range(segments + 1):
        x = x_start + i * dx
        y = y_start + (0 if i % 2 == 0 else height)
        x_vals.append(x)
        y_vals.append(y)

    return x_vals, y_vals

def plot_trajectories():
    plt.figure(figsize=(8, 8))
    plt.grid(True)
    plt.gca().set_aspect('equal', adjustable='box')

    x_oval, y_oval = oval_trajectory()
    plt.plot(x_oval, y_oval, label='Óvalo', linewidth=2)

    x_eight, y_eight = figure_eight_trajectory()
    plt.plot(x_eight, y_eight, label='Ocho', linewidth=2)

    x_zigzag, y_zigzag = zigzag_trajectory()
    plt.plot(x_zigzag, y_zigzag, label='Zigzag', linewidth=2, marker='o')

    plt.title('Trayectorias: Óvalo, Ocho y Zigzag')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.xlim(-1, 11)
    plt.ylim(3, 8)
    plt.show()

def main():
    plot_trajectories()

if __name__ == '__main__':
    main()

