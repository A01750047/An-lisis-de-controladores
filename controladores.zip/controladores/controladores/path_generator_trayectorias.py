#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import math
import sys
import math

class TimeDrivenTrajectoryPublisher(Node):
    def __init__(self, trajectory, dt=0.3): # dt definirlo dependiendo cada trayectoria para cumplir con 1 minuto
        super().__init__('trajectory_publisher')
        self.trajectory = trajectory
        self.index = 0
        self.pub = self.create_publisher(Point, 'next_point', 10)
        self.timer = self.create_timer(dt, self.publish_next_point)
	
	# Publicación de puntos conforme al tiempo
    def publish_next_point(self):
        if self.index < len(self.trajectory):
            point = self.trajectory[self.index]
            self.pub.publish(point)
            self.get_logger().info(
                f'Tiempo {self.index * 0.5:.1f}s - Publicando punto ({point.x:.2f}, {point.y:.2f})'
            )
            self.index += 1
        else:
            # Enviar punto especial para indicar fin
            finish_point = Point()
            finish_point.x = float('nan')
            finish_point.y = float('nan')
            finish_point.z = 0.0
            self.pub.publish(finish_point)
            self.get_logger().info('Trayectoria completada. Punto final enviado.')
            self.timer.cancel()

# === Trayectorias ===

# Óvalo	
def generate_oval_trajectory(start=(5.5, 5.5), a=3.0, b=2, points=100):
    # Inicia en el extremo derecho del óvalo (ángulo t = 0)
    cx = start[0] - a  # mueve el centro a la izquierda
    cy = start[1]
    trajectory = []
    for i in range(points):
        t = 2 * math.pi * i / points
        x = cx + a * math.cos(t)
        y = cy + b * math.sin(t)
        trajectory.append(Point(x=x, y=y, z=0.0))
    return trajectory

# Ocho
def generate_figure_eight_trajectory(start=(5.5, 5.5), a=3.5, b=2.0, points=200):
    # Inicia en el centro del ocho, en t=0
    cx, cy = start
    trajectory = []
    for i in range(points):
        t = 2 * math.pi * i / points
        x = cx + a * math.sin(t)
        y = cy + b * math.sin(t) * math.cos(t)
        trajectory.append(Point(x=x, y=y, z=0.0))
    return trajectory

# Zig zag
def generate_zigzag_trajectory(start=(5.5, 5.5), width=4.0, height=2.0, segments=4):
    # Inicia con la primera esquina inferior izquierda en start=(5.5, 5.5)
    x_start, y_start = start
    dx = width / segments
    trajectory = []
    for i in range(segments + 1):
        x = x_start + i * dx
        y = y_start + (0 if i % 2 == 0 else height)  # empieza hacia arriba
        trajectory.append(Point(x=x, y=y, z=0.0))
    return trajectory


def main(args=None):
    rclpy.init(args=args)
	
	# Elegir trayectoria a realizar
    if len(sys.argv) > 1:
        shape = sys.argv[1].lower()
    else:
        shape = 'oval'

    if shape == 'oval':
        trajectory = generate_oval_trajectory()
    elif shape == 'eight':
        trajectory = generate_figure_eight_trajectory()
    elif shape == 'zigzag':
        trajectory = generate_zigzag_trajectory()
    else:
        print(f'Trayectoria desconocida: {shape}')
        return

    node = TimeDrivenTrajectoryPublisher(trajectory, dt=0.3)# dt calibrado para Ocho
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

