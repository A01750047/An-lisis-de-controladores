#!/usr/bin/env python3
import rclpy
import math
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist, Point
from std_msgs.msg import Bool
import sys

class CloseLoopController(Node):
    def __init__(self, control_mode='lyapunov'):
        super().__init__('close_loop_controller')
		
		# Publicadores
        self.pub_cmd = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.pub_reached = self.create_publisher(Bool, 'point_reached', 10)
		
		# Suscriptores
        self.sub_pose = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.sub_next_point = self.create_subscription(Point, 'next_point', self.next_point_callback, 10)

        self.x = None
        self.y = None
        self.theta = None

        self.xd = None
        self.yd = None

        self.point_index = 0
        self.point_times = []
        self.point_errors = []

        self.arrived_current_point = True
        self.start_time = None
        self.control_mode = control_mode  # En terminal seleccionar controlador

        self.get_logger().info(f'Modo de control seleccionado: {self.control_mode}')

        self.timer = self.create_timer(0.1, self.control_loop)

    def pose_callback(self, msg):
        self.x = msg.x
        self.y = msg.y
        self.theta = msg.theta
	
	# Recibe el punto del Path Generator
    def next_point_callback(self, msg):
        self.xd = msg.x
        self.yd = msg.y
        self.arrived_current_point = False
        self.start_time = self.get_clock().now()
        self.get_logger().info(f'Nuevo objetivo recibido: ({self.xd:.2f}, {self.yd:.2f})')

    def control_loop(self):
        if None in [self.x, self.y, self.theta, self.xd, self.yd]:
            return
		
		# Cálculo del error de distancia y orientación
        dx = self.xd - self.x
        dy = self.yd - self.y
        distance = math.sqrt(dx**2 + dy**2)
        angle_goal = math.atan2(dy, dx)
        angle_error = self.normalize_angle(angle_goal - self.theta)
		
		# Detener robot si ya llegó al punto con el error mencionado en el reporte
        if distance < 0.05 and not self.arrived_current_point:
            elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
            self.point_times.append(elapsed)
            self.point_errors.append(distance)
            self.get_logger().info(f'Punto {self.point_index+1} alcanzado en {elapsed:.2f}s con error {distance:.3f}m')
			
			# Waypoint alcanzado
            msg_reached = Bool()
            msg_reached.data = True
            self.pub_reached.publish(msg_reached)

            self.point_index += 1
            self.arrived_current_point = True

            self.publish_velocity(0.0, 0.0)
            return

        if self.arrived_current_point:
            self.publish_velocity(0.0, 0.0)
            return
		
		# Selección del controlador
        if self.control_mode == 'lyapunov':
            self.lyapunov_control(distance, angle_error, angle_goal)
        elif self.control_mode == 'turn_then_go':
            self.turn_then_go(distance, angle_error)
        elif self.control_mode == 'turn_while_go':
            self.turn_while_go(distance, angle_error)
        elif self.control_mode == 'pure_pursuit':
            self.pure_pursuit()
        else:
            self.get_logger().warn(f'Modo de control desconocido: {self.control_mode}, deteniendo el robot.')
            self.publish_velocity(0.0, 0.0)
	
	# Controlador Turn then Go
    def turn_then_go(self, distance, angle_error):
        Kv, Kw = 0.2, 0.85
        msg = Twist()
        if distance > 0.05:
            msg.linear.x = 0.0 if abs(angle_error) > 0.05 else Kv
            msg.angular.z = Kw * angle_error
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0
        self.pub_cmd.publish(msg)
	
	# Controlador Turn while Go
    def turn_while_go(self, distance, angle_error):
        Kv, Kw = 0.2, 0.45
        msg = Twist()
        if distance > 0.05:
            msg.linear.x = Kv * 0.3 if abs(angle_error) > math.pi / 3 else Kv
            msg.angular.z = Kw * angle_error
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0
        self.pub_cmd.publish(msg)
	
	# Controlador basado en Lyapunov
    def lyapunov_control(self, distance, angle_error, angle_goal):
        k1, k2 = 2.0, 1.0
        v_r = min(0.2, 0.5 * distance)
        v = v_r * math.cos(angle_error)
        if abs(angle_error) > 0.03:
            correction = (v_r * math.cos(angle_error) * math.sin(angle_error) * (angle_error + k2 * angle_goal)) / angle_error
        else:
            correction = 0.0
        w = k1 * angle_error + correction
        w = max(min(w, 0.6), -0.6)
        msg = Twist()
        msg.linear.x = v
        msg.angular.z = w
        self.pub_cmd.publish(msg)
	
	# Controlador basado en Pure pursuit
    def pure_pursuit(self):
        L = 0.6
        max_linear_speed = 0.2
        max_angular_speed = 0.65

        msg = Twist()
        Dx = self.xd - self.x
        Dy = self.yd - self.y
        distance = math.sqrt(Dx ** 2 + Dy ** 2)

        if distance > 0.05:
            cq = math.cos(self.theta)
            sq = math.sin(self.theta)
            v = Dx * cq + Dy * sq
            w = (1 / L) * (Dy * cq - Dx * sq)
            v = max(min(v, max_linear_speed), -max_linear_speed)
            w = max(min(w, max_angular_speed), -max_angular_speed)
            msg.linear.x = v
            msg.angular.z = w
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0

        self.pub_cmd.publish(msg)

    def publish_velocity(self, linear_x, angular_z):
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z
        self.pub_cmd.publish(msg)

    @staticmethod
    def normalize_angle(angle):
        return math.atan2(math.sin(angle), math.cos(angle))
	
	# Impresión de resultados para mayor exactitud
    def print_results(self):
        self.get_logger().info('====== Resultados Finales ======')
        for i, (t, e) in enumerate(zip(self.point_times, self.point_errors)):
            self.get_logger().info(f'Punto {i+1}: Tiempo = {t:.2f}s, Error = {e:.3f}m')

def main(args=None):
    rclpy.init(args=args)

    # Obtener el modo de control desde la terminal
    control_mode = 'lyapunov'  # valor por defecto
    if len(sys.argv) > 1:
        control_mode = sys.argv[1]

    node = CloseLoopController(control_mode=control_mode)
    rclpy.spin(node)
    node.print_results()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

