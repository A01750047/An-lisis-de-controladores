#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from std_msgs.msg import Bool

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')
        self.publisher = self.create_publisher(Point, 'next_point', 10)
        self.subscription = self.create_subscription(Bool, 'point_reached', self.point_reached_callback, 10)
        self.start_time = self.get_clock().now()
		
		#Prueba 1: primeros waypoints
        #self.points = [
        #    [7.5, 5.5],
        #    [7.5, 7.5],
        #    [5.5, 7.5],
        #    [5.5, 5.5]
        #]
        
        # Puebaa 2 Waypoints
        self.points = [
            [7.5, 7.5],
            [3.5, 7.5],
            [5.5, 5.5],
            [3.5, 3.5],
            [7.5, 3.5],
            [5.5, 5.5]
        ]
        self.index = 0
        self.timer = self.create_timer(1.0, self.publish_point)
        self.point_ready_to_send = True
	
	#Publicar el waypoint y tomar el tiempo
    def publish_point(self):
        if self.point_ready_to_send and self.index < len(self.points):
            point = self.points[self.index]
            msg = Point()
            msg.x = point[0]
            msg.y = point[1]
            msg.z = 0.0  # No se usa, pero es obligatorio
            self.publisher.publish(msg)
            elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
            self.get_logger().info(f'[{elapsed:.2f}s] Punto publicado: {point}')
            self.point_ready_to_send = False

        elif self.index >= len(self.points):
            self.get_logger().info('Todos los puntos visitados. Finalizando nodo.')
            rclpy.shutdown()
	
	# Recibe del codigo de controlador la bandera de Waaypoint alcanzado
    def point_reached_callback(self, msg: Bool):
        if msg.data:
            self.get_logger().info(f'Confirmación llegada punto {self.index + 1}')
            self.index += 1
            self.point_ready_to_send = True

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

