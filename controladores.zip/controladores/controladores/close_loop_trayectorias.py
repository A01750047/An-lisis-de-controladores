#!/usr/bin/env python3
import rclpy
import math
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist, Point
import sys
import math

class CloseLoopController(Node):
    def __init__(self, control_mode='lyapunov'):
        super().__init__('close_loop_controller')
		
		# Publicador
        self.pub_cmd = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # Suscriptores
        self.sub_pose = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.sub_next_point = self.create_subscription(Point, 'next_point', self.next_point_callback, 10)

        self.x = None
        self.y = None
        self.theta = None

        self.xd = None
        self.yd = None

        self.control_mode = control_mode
        self.point_errors = []

        self.finished = False  # bandera que indica fin de trayectoria
		
		# Controlador seleccionado
        self.get_logger().info(f'Modo de control seleccionado: {self.control_mode}')
        self.timer = self.create_timer(0.1, self.control_loop)

    def pose_callback(self, msg):
        self.x = msg.x
        self.y = msg.y
        self.theta = msg.theta
	
	# Recibir puntos publicados por el tiempo de la simulación del Path Generator
    def next_point_callback(self, msg):
        # Detectar si el punto es NaN (fin de trayectoria)
        if math.isnan(msg.x) or math.isnan(msg.y):
            self.finished = True
            self.get_logger().info('Se recibió señal de fin de trayectoria.')
            return
        self.xd = msg.x
        self.yd = msg.y
        self.finished = False  # Si vuelve a recibir punto válido, reinicia bandera
	
    def control_loop(self):
        if None in [self.x, self.y, self.theta]:
            return

        if self.finished:
            # Parar tortuga
            self.publish_velocity(0.0, 0.0)
            # Calcular distancia restante al último punto válido
            if self.xd is not None and self.yd is not None:
                distance_to_goal = math.sqrt((self.xd - self.x) ** 2 + (self.yd - self.y) ** 2)
                self.get_logger().info(f'Distancia restante al último punto: {distance_to_goal:.3f} m')
            # Cancelar timer para no seguir ejecutando
            self.timer.cancel()
            return
		
		# Cálculo de errores de distancia y orientación
        if None in [self.xd, self.yd]:
            return

        dx = self.xd - self.x
        dy = self.yd - self.y
        distance = math.sqrt(dx ** 2 + dy ** 2)
        self.point_errors.append(distance)

        angle_goal = math.atan2(dy, dx)
        angle_error = self.normalize_angle(angle_goal - self.theta)
		
		# Selección del controlador
        if self.control_mode == 'lyapunov':
            self.lyapunov_control(distance, angle_error, angle_goal)
        elif self.control_mode == 'turn_then_go':
            self.turn_then_go(distance, angle_error)
        elif self.control_mode == 'turn_while_go':
            self.turn_while_go(distance, angle_error)
        elif self.control_mode == 'pure_pursuit':
            self.pure_pursuit()
        else:
            self.get_logger().warn(f'Modo de control desconocido: {self.control_mode}')
            self.publish_velocity(0.0, 0.0)
	
	# Controlador Turn then Go
    def turn_then_go(self, distance, angle_error):
        Kv, Kw = 0.2, 0.85
        msg = Twist()
        msg.linear.x = 0.0 if abs(angle_error) > 0.05 else Kv
        msg.angular.z = Kw * angle_error
        self.pub_cmd.publish(msg)
	
	# Controlador Turn while Go
    def turn_while_go(self, distance, angle_error):
        Kv, Kw = 0.2, 0.45
        msg = Twist()
        msg.linear.x = Kv * 0.3 if abs(angle_error) > math.pi / 3 else Kv
        msg.angular.z = Kw * angle_error
        self.pub_cmd.publish(msg)
	
	# Controlador basado en Lyapunov
    def lyapunov_control(self, distance, angle_error, angle_goal):
        k1, k2 = 2.0, 1.0
        v_r = min(0.2, 0.5 * distance)
        v = v_r * math.cos(angle_error)
        correction = 0.0
        if abs(angle_error) > 0.03:
            correction = (v_r * math.cos(angle_error) * math.sin(angle_error) * (angle_error + k2 * angle_goal)) / angle_error
        w = k1 * angle_error + correction
        w = max(min(w, 0.6), -0.6)
        msg = Twist()
        msg.linear.x = v
        msg.angular.z = w
        self.pub_cmd.publish(msg)
        
	# Controlador basado en Pure pursuit
    def pure_pursuit(self):
        L = 0.6
        max_linear_speed = 0.2
        max_angular_speed = 0.65

        Dx = self.xd - self.x
        Dy = self.yd - self.y
        distance = math.sqrt(Dx ** 2 + Dy ** 2)

        msg = Twist()
        if distance > 0.05:
            cq = math.cos(self.theta)
            sq = math.sin(self.theta)
            v = Dx * cq + Dy * sq
            w = (1 / L) * (Dy * cq - Dx * sq)
            v = max(min(v, max_linear_speed), -max_linear_speed)
            w = max(min(w, max_angular_speed), -max_angular_speed)
            msg.linear.x = v
            msg.angular.z = w
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0

        self.pub_cmd.publish(msg)

    def publish_velocity(self, linear_x, angular_z):
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z
        self.pub_cmd.publish(msg)

    @staticmethod
    def normalize_angle(angle):
        return math.atan2(math.sin(angle), math.cos(angle))
	
	# Impresión de resultados para mayor exactitud
    def print_results(self):
        if not self.point_errors:
            self.get_logger().info("No hay errores registrados.")
            return

        avg_error = sum(self.point_errors) / len(self.point_errors)
        max_error = max(self.point_errors)
        self.get_logger().info('====== Seguimiento de Trayectoria ======')
        self.get_logger().info(f'Error promedio: {avg_error:.3f} m')
        self.get_logger().info(f'Error máximo: {max_error:.3f} m')

def main(args=None):
    rclpy.init(args=args)
	
	# Obtener el modo de control desde la terminal
    control_mode = 'lyapunov' # valor por defecto
    if len(sys.argv) > 1:
        control_mode = sys.argv[1]

    node = CloseLoopController(control_mode=control_mode)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.print_results()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

