from setuptools import find_packages, setup

package_name = 'controladores'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='daniel',
    maintainer_email='daniel@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        	"close_loop_cuadrantes = controladores.close_loop_cuadrantes:main",
        	"close_loop_trayectorias = controladores.close_loop_trayectorias:main",
        	"path_generator_cuadrantes = controladores.path_generator_cuadrantes:main",
        	"path_generator_trayectorias = controladores.path_generator_trayectorias:main",
        	"trayectorias = controladores.trayectorias:main",
        ],
    },
)
